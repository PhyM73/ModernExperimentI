#include "TCanvas.h"
#include "TChain.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1D.h"
#include "TLine.h"
#include "TMath.h"
#include "TString.h"
#include "TVirtualFitter.h"

void load() {
  Int_t iChn;
  Int_t y;
  TString filename = "Na.root";
  TString readfile = "Na.txt";
  FILE *fp = fopen(readfile.Data(), "r");

  TFile *hfile = TFile::Open(filename, "RECREATE");
  TTree *tree = new TTree("T", "T");
  tree->Branch("iChn", &iChn, "iChn/I");

  char line[10];
  while (fgets(line, 10, fp)) {
    sscanf(line, "%d %d", &iChn, &y);
    // cout << iChn << " y " << y << endl;
    for (int i = 0; i < y; i++) {
      tree->Fill();
    }
  }
  tree->Write();

  fclose(fp);
}