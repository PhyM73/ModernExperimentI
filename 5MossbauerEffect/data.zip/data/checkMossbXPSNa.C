#include "TCanvas.h"
#include "TChain.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1D.h"
#include "TLine.h"
#include "TMath.h"
#include "TString.h"
#include "TVirtualFitter.h"

void LineX1(Double_t atX, Int_t iColor = kRed, Int_t iStyle = 1, Double_t iWidth = 1);
void fitSpe(TH1D *h);
void checkMossbXPSNa(Int_t isFit = 1, Double_t winL = 35, Double_t winR = 65) {
  gStyle->SetOptStat(0);
  TChain chain("T");
  chain.Add("Na.root");
  TCanvas *c1 = new TCanvas("c1", "", 1200, 800);
  c1->Divide(1, 1);
  c1->cd(1);
  // chain.Draw("energy");
  // c1->cd(2);
  // chain.Draw("nPhoton");
  LineX1(winL);
  LineX1(winR);

  // c1->cd(3);
  TH1D *h = new TH1D("h", ";channel;Counts", 512, 0, 512);
  // TH1D *h2 = (TH1D *)h->Clone("h2");
  chain.Draw("iChn>>h");
  // c1->cd(4);
  // chain.Draw("iChn>>h2",Form("nPhoton>%.0f && nPhoton<%.0f",winL,winR));

  //save to a txt file
  // TString txtFile="XiaoPuSuanNa.txt";
  // FILE* pf = fopen(txtFile.Data(),"wt");
  // for(Int_t i=0; i<h2->GetNbinsX(); i++){
  //   Int_t Y = h2->GetBinContent(i+1);
  //   fprintf(pf,"%d %d\n",i+1,Y);
  // }
  // fclose(pf);
  //fit the finial spectrum
  if (isFit > 0) fitSpe(h);
  // printf("Spectrum data saved in %s as txt file\n",txtFile.Data());
}

void LineX1(Double_t atX, Int_t iColor, Int_t iStyle, Double_t iWidth) {
  gPad->Modified();
  gPad->Update();
  TLine *l1 = new TLine(atX, gPad->GetUymin(), atX, gPad->GetUymax());
  l1->SetLineColor(iColor);
  l1->SetLineStyle(iStyle);
  l1->SetLineWidth(iWidth);
  l1->Draw();
}

Double_t LZFun(Double_t E, Double_t E0, Double_t Gamma) {
  Double_t d = Gamma * Gamma / 4.;
  return d / ((E - E0) * (E - E0) + d);
}

Double_t LZPeaks(Double_t *x, Double_t *par) {
  Double_t val = par[12];
  for (Int_t i = 0; i < 4; i++) {
    Int_t j = 3 * i;
    val = val + par[j] * LZFun(x[0], par[j + 1], par[j + 2]);
  }
  return val;
}

void fitSpe(TH1D *h) {
  // Creates a Root function based on function LZPeaks
  Int_t LwX = 0, HiX = 511, NPar = 13;  // total 4 peaks,each with 3 Parameters, 36th as constant
  TF1 *func = new TF1("func", LZPeaks, LwX, HiX, NPar);
  //initial values
  Double_t params[13];
  //const
  params[12] = h->GetBinContent(4);
  printf("params[12]=%.1f\n", params[12]);
  //peak pos
  Int_t N = 0;
  // params[N + 1] = 96;
  // N += 3;  //0
  // params[N + 1] = 176.5;
  // N += 3;  //1

  // params[N + 1] = 336;
  // N += 3;  //0
  // params[N + 1] = 417;
  // N += 3;  //1
  params[N + 1] = 119;
  N += 3;  //0
  params[N + 1] = 149;
  N += 3;  //1

  params[N + 1] = 360;
  N += 3;  //0
  params[N + 1] = 390;
  N += 3;  //1

  //peak Gamma and Amplititude
  for (Int_t i = 0; i < 4; i++) {
    Int_t j = i * 3;
    params[j + 2] = 6;  //Gamma

    //peak Deepth
    Int_t iP = TMath::Nint(params[j + 1]);
    Double_t hi = h->GetBinContent(iP + 1);
    params[j] = hi - params[12];

    //parameter name
    func->SetParName(j, Form("Amp%d", i));
    func->SetParName(j + 1, Form("E%d", i));
    func->SetParName(j + 2, Form("Gamma%d", i));
    func->SetParLimits(j + 2, 2, 20);
  }
  func->SetParName(12, "BaseLine");
  // We have more than the default 25 parameters
  TVirtualFitter::Fitter(h, 13);
  func->SetParameters(params);
  func->SetNpx(1000);
  h->SetMarkerStyle(20);
  h->SetMarkerSize(0.8);
  h->SetMarkerColor(kBlue);
  h->SetLineColor(kBlue);
  //TCanvas *c1 = new TCanvas("c1","");
  h->Draw("PE");
  h->Fit(func);
  func->Draw("same");
  TString rltFile = "FitXiaoPuSuanNanSpe.root";
  TFile *fout = new TFile(rltFile.Data(), "recreate");
  h->Write();
  func->Write();
  fout->Close();
  delete fout;
  FILE *pf = fopen("Nafit.txt", "wt");
  for (Int_t i = 0; i < 4; i++) {
    Int_t j = i * 3;
    printf("params[N+1] = %.1f; N+=3;\n", func->GetParameter(j + 1));
    fprintf(pf, "%d & $ %.1f \\pm %.1f $ & $ %.3f \\pm %.3f$\n ", i + 1, func->GetParameter(j + 1), func->GetParError(j + 1), func->GetParameter(j + 2), func->GetParError(j + 2));
    // fprintf(pf, "E%d %.3f pm %.3f\n", i, func->GetParameter(j + 1), func->GetParError(j + 1));
  }

  // //Gamma
  // for (Int_t i = 0; i < 4; i++) {
  //   Int_t j = i * 3;
  //   printf("params[N+2] = %.1f; N+=3;\n", func->GetParameter(j + 2));
  //   fprintf(pf, "Gamma%d %.3f pm %.3f\n", i, func->GetParameter(j + 2), func->GetParError(j + 2));
  // }
  // //Amp
  // for (Int_t i = 0; i < 4; i++) {
  //   Int_t j = i * 3;

  //   fprintf(pf, "Amp%d %.3f pm %.3f\n", i, func->GetParameter(j), func->GetParError(j));
  // }
  fclose(pf);

  printf("Fitted Spectrum saved in %s\n", rltFile.Data());
}
