#include "TCanvas.h"
#include "TChain.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1D.h"
#include "TLine.h"
#include "TMath.h"
#include "TString.h"
#include "TVirtualFitter.h"

void LineX1(Double_t atX, Int_t iColor = kRed, Int_t iStyle = 1, Double_t iWidth = 1);
void fitSpe(TH1D *h);
void checkMossb(Int_t isFit = 1, Double_t winL = 35, Double_t winR = 65) {
  gStyle->SetOptStat(0);
  TChain chain("T");
  chain.Add("Fe.root");
  TCanvas *c1 = new TCanvas("c1", "", 1200, 800);
  c1->Divide(1, 1);
  // c1->cd(1);
  // chain.Draw("energy");
  // c1->cd(2);
  // chain.Draw("nPhoton");
  LineX1(winL);
  LineX1(winR);

  // c1->cd(3);
  TH1D *h = new TH1D("h", ";channel;Counts", 512, 0, 512);
  // TH1D *h2 = (TH1D *)h->Clone("h2");
  // chain.Draw("iChn>>h");
  c1->cd(1);
  // chain.Draw("iChn>>h2", Form("nPhoton>%.0f && nPhoton<%.0f", winL, winR));
  chain.Draw("iChn>>h");

  //save to a txt file
  TString txtFile = "alphaFe.txt";
  FILE *pf = fopen(txtFile.Data(), "wt");
  for (Int_t i = 0; i < h->GetNbinsX(); i++) {
    Int_t Y = h->GetBinContent(i + 1);
    fprintf(pf, "%d %d\n", i + 1, Y);
  }
  fclose(pf);
  //fit the finial spectrum
  if (isFit == 1) fitSpe(h);
  printf("Spectrum data saved in %s as txt file\n", txtFile.Data());
  TFile *fout = new TFile("rltMossbSpe.root", "recreate");
  h->Write();
  fout->Close();
}

void LineX1(Double_t atX, Int_t iColor, Int_t iStyle, Double_t iWidth) {
  gPad->Modified();
  gPad->Update();
  TLine *l1 = new TLine(atX, gPad->GetUymin(), atX, gPad->GetUymax());
  l1->SetLineColor(iColor);
  l1->SetLineStyle(iStyle);
  l1->SetLineWidth(iWidth);
  l1->Draw();
}

Double_t LZFun(Double_t E, Double_t E0, Double_t Gamma) {
  if (abs(E - E0) > 5 * Gamma) return 0;
  Double_t d = Gamma * Gamma / 4.;
  return d / ((E - E0) * (E - E0) + d);
}

Double_t LZPeaks(Double_t *x, Double_t *par) {
  Double_t val = par[36];
  for (Int_t i = 0; i < 12; i++) {
    Int_t j = 3 * i;
    val = val + par[j] * LZFun(x[0], par[j + 1], par[j + 2]);
  }
  return val;
}

void fitSpe(TH1D *h) {
  // Creates a Root function based on function LZPeaks
  Int_t LwX = 0, HiX = 511, NPar = 37;  // total 12 peaks,each with 3 Parameters, 36th as constant
  TF1 *func = new TF1("func", LZPeaks, LwX, HiX, NPar);
  //initial values
  Double_t params[37];
  //const
  params[36] = h->GetBinContent(2);
  //peak pos
  Int_t N = 0;
  params[N + 1] = 45.2;
  N += 3;

  params[N + 1] = 81.7;
  N += 3;
  params[N + 1] = 118.3;
  N += 3;
  params[N + 1] = 144.8;
  N += 3;
  params[N + 1] = 181.3;
  N += 3;
  params[N + 1] = 218.9;
  N += 3;
  params[N + 1] = 292.9;
  N += 3;
  params[N + 1] = 331.5;
  N += 3;
  params[N + 1] = 368.3;
  N += 3;
  params[N + 1] = 395.3;
  N += 3;
  params[N + 1] = 431.4;
  N += 3;
  params[N + 1] = 467.9;
  N += 3;
  //peak Gamma

  N = 0;
  params[N + 2] = 7.6;
  N += 3;
  params[N + 2] = 3.5;
  N += 3;
  params[N + 2] = 4.2;
  N += 3;
  params[N + 2] = 3.7;
  N += 3;
  params[N + 2] = 3.4;
  N += 3;
  params[N + 2] = 6.7;
  N += 3;
  params[N + 2] = 9.7;
  N += 3;
  params[N + 2] = 3.6;
  N += 3;
  params[N + 2] = 6.1;
  N += 3;
  params[N + 2] = 3.0;
  N += 3;
  params[N + 2] = 3.6;
  N += 3;
  params[N + 2] = 4.8;
  N += 3;

  //peak Gamma and Amplititude
  for (Int_t i = 0; i < 12; i++) {
    Int_t j = i * 3;
    //params[j+2] = 10;//Gamma

    //peak Deepth
    Int_t iP = TMath::Nint(params[j + 1]);
    Double_t hi = h->GetBinContent(iP + 1);
    params[j] = hi - params[36];

    //parameter name
    func->SetParName(j, Form("Amp%d", i));
    func->SetParName(j + 1, Form("E%d", i));
    func->SetParName(j + 2, Form("Gamma%d", i));
    // func->SetParLimits(j,params[j]*10,params[j]*0.1);
    func->SetParLimits(j + 1, params[j + 1] - 3, params[j + 1] + 3);
    Double_t GammaL = params[j + 2] - 5;
    Double_t GammaH = params[j + 2] + 5;
    if (GammaL < 2) GammaL = 2;
    func->SetParLimits(j + 2, GammaL, GammaH);
  }
  func->SetParName(36, "BaseLine");
  // We have more than the default 25 parameters
  TVirtualFitter::Fitter(h, 37);
  func->SetParameters(params);
  func->SetNpx(1000);
  h->SetMarkerStyle(20);
  h->SetMarkerSize(0.8);
  h->SetMarkerColor(kBlue);
  h->SetLineColor(kBlue);
  //TCanvas *c1 = new TCanvas("c1","");
  h->Draw("PE");
  h->Fit(func);
  //reset limits and re-fit
  for (Int_t j = 0; j < 2; j++) {
    for (Int_t i = 0; i < 37; i++) {
      Double_t val = func->GetParameter(i);
      Double_t Err = func->GetParError(i);
      Double_t RL = val - (5 + j) * Err;
      Double_t RR = val + (5 + j) * Err;
      if ((j % 3) == 2)
        if (RL < 2) RL = 2;  //Gamma
      func->SetParLimits(i, RL, RR);
    }
    printf("fitting %d\n", j);
    h->Fit(func);
  }

  TString rltFile = "FitAlphaFeSpe.root";
  TFile *fout = new TFile(rltFile.Data(), "recreate");
  h->Write();
  func->Write();
  fout->Close();
  delete fout;
  printf("Fitted Spectrum saved in %s\n", rltFile.Data());
  FILE *pf = fopen("Fefit.txt", "wt");
  for (Int_t i = 0; i < 12; i++) {
    Int_t j = i * 3;
    printf("params[N+1] = %.1f; N+=3;\n", func->GetParameter(j + 1));
    // fprintf(pf, "E%d %.3f pm %.3f\n", i, func->GetParameter(j + 1), func->GetParError(j + 1));
    fprintf(pf, "%d & $ %.1f \\pm %.1f $ & $ %.3f \\pm %.3f$\n ", i + 1, func->GetParameter(j + 1), func->GetParError(j + 1), func->GetParameter(j + 2), func->GetParError(j + 2));
  }

  // //Gamma
  // for (Int_t i = 0; i < 12; i++) {
  //   Int_t j = i * 3;
  //   printf("params[N+2] = %.1f; N+=3;\n", func->GetParameter(j + 2));
  //   fprintf(pf, "Gamma%d %.3f pm %.3f\n", i, func->GetParameter(j + 2), func->GetParError(j + 2));
  // }
  // //Amp
  // for (Int_t i = 0; i < 12; i++) {
  //   Int_t j = i * 3;

  //   fprintf(pf, "Amp%d %.3f pm %.3f\n", i, func->GetParameter(j), func->GetParError(j));
  // }
  fclose(pf);
}
